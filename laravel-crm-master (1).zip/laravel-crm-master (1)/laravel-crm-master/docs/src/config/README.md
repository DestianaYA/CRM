---
sidebar: auto
---

# Config

## foo

- Type: `string`
- Default: `/`

## bar

- Type: `string`
- Default: `/`
