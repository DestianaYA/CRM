<?php

namespace VentureDrake\LaravelCrm\Http\Controllers\Integrations;

use Illuminate\Routing\Controller;

class XeroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        dd('xero integration');
    }
}
