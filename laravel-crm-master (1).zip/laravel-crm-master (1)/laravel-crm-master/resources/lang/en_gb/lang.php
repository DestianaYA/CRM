<?php

return [
    'organization' => 'organisation',
    'organizations' => 'organisations',
    'create_organization' => 'create organisation',
    'edit_organization' => 'edit organisation',
    'add_organization' => 'add organisation',
    'organization_stored' => 'organisation stored',
    'organization_updated' => 'organisation updated',
    'organization_deleted' => 'organisation deleted',
    'back_to_organizations' => 'back to organisations',
    'total_organizations' => 'total organisations',
    'organization_name' => 'organisation name',
    'related_organizations' => 'related organisations',
    'link_an_organization' => 'link an organisation',
    'link_organization' => 'link organisation',
    'postcode' => 'postcode',
    'back_to_organisations' => 'back to organisations',
];
