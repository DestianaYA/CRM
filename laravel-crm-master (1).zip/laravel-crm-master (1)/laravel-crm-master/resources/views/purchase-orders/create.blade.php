@extends('laravel-crm::layouts.app')

@section('content')

    @include('laravel-crm::purchase-orders.partials.card-create')

@endsection
