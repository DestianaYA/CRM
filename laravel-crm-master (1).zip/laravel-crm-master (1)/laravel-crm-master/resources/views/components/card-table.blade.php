<div class="card-body p-0 table-responsive text-nowrap">
    {{ $slot }}
</div>