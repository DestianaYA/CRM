<div class="card-footer">
    {{ $slot }}
</div>