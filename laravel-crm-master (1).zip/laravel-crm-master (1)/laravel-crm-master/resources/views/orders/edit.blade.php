@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::orders.partials.card-edit')
    
@endsection