@extends('laravel-crm::layouts.app')

@section('content')

    @include('laravel-crm::tasks.partials.card-index')

@endsection