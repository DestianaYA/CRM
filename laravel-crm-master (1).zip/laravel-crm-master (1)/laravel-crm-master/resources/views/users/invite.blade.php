@extends('laravel-crm::layouts.app')

@section('content')
    
    @include('laravel-crm::users.partials.card-invite')

@endsection